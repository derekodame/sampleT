<?php 
error_reporting(E_ALL^E_NOTICE);
define("host","127.0.0.1")? null  : define("host","127.0.0.1");
define("user","root")     ?	null  :	define("user","root");
define("pass","")		  ?	null  :	define("pass","");
define("dbname","itserve")?	null  :	define("dbname","itserve");

?>
<?php  
/*error_reporting(E_ALL^E_NOTICE);
define("host","mysql.serversfree.com")? null  : define("host","mysql.serversfree.com");
define("user","u521606808_s")     ?	null  :	define("user","u521606808_s");
define("pass","stecks0298")		  ?	null  :	define("pass","stecks0298");
define("dbname","u521606808_s")?	null  :	define("dbname","u521606808_s");
*/
?>