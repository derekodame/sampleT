


<?php 
include("../include/updates.php");
?>
<script src="../javascript/jquery-1.8.3.min.js"></script>
<script src="../javascript/picture_edit.js"></script>

</body>
</html>