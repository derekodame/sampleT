<?php include("../include/header.php");?>

<span class="outputsearch">.<br/>

</span>
<div class="showcomment" contenteditable="false" style="background-color:white
<?php 
/*$query=mysql_query("SELECT * FROM pannel where email = '$emailss'");
while($row=mysql_fetch_array($query)){
	$bg = $row['bgcolor'];
	
	echo $bg;
}*/
?>">

<div id='sss'class="showcomment2"  > 
<?php  //include"../include/searchh.php";?>
</div>
</div>




<?php include("../include/footer.php");?>